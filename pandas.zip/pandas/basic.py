import pandas as pd

df=pd.read_csv("D:\python\pandas\sales_data_sample.csv",encoding="latin1")

print(df)